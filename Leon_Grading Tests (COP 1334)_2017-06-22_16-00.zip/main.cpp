#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main()
{
    double score,average;
    double test1,test2,test3,test4;
    int students;
   //read grades.txt
   ifstream file;
   file.open("grades.txt");

   string STRING;
  /* while(!file.eof()){
    getline(file, STRING);
    cout << STRING;
   }
   file.close(); */
   while(!file.eof()){
        file>>test1>>test2>>test3>>test4;
        score=test1+test2+test3+test4;
        average=score/4;
                if(average>=90&&average<=100){
    cout << average << " A" <<endl;}
                else if(average>=80&&average<=89){
    cout << average << " B" <<endl;}
                else if(average>=70&&average<=79){
    cout << average << " C" <<endl;}
                else if(average>=60&&average<=69){
    cout << average << " D" <<endl;}
                else if(average<=59){
    cout << average << " F" <<endl;}
        }
    file.close();


    return 0;
}

